<#
.SYNOPSIS
    Enables BitLocker in an ESP-safe way for Windows Autopilot / Intune.

.DESCRIPTION
    Modernized BitLocker enablement script for Autopilot ESP reliability.

    Key improvements over older ESP BitLocker scripts:
      - Does NOT wait for encryption to reach 100% before exiting.
      - Treats EncryptionInProgress as success when required protectors are present.
      - Does NOT require exactly two key protectors.
      - Adds missing TPM and Recovery Password protectors when needed.
      - Attempts recovery key escrow to Entra ID / Azure AD.
      - Creates a retry scheduled task if escrow fails because the device is not ready yet.
      - Runs safely in SYSTEM context as a Win32 app during ESP.
      - Relaunches in 64-bit PowerShell if accidentally started from 32-bit PowerShell.
      - Writes CMTrace-compatible logs.

.NOTES
    Suggested Intune Win32 install command:
      powershell.exe -ExecutionPolicy Bypass -NoProfile -File .\Enable-BitLockerEncryption-ESPModern.ps1

    Suggested Intune settings:
      Install behavior: System
      Run command line as 32-bit process on 64-bit clients: No
      Device restart behavior: No specific action

    Detection recommendation:
      Success should be FullyEncrypted OR EncryptionInProgress with TPM + RecoveryPassword protectors present.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidateSet('Aes128', 'Aes256', 'XtsAes128', 'XtsAes256')]
    [string]$EncryptionMethod = 'XtsAes256',

    [Parameter(Mandatory = $false)]
    [ValidateSet('Encrypt', 'Backup')]
    [string]$OperationalMode = 'Encrypt',

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$CompanyName = 'CHP',

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$LogPath = 'C:\ProgramData\CHP\Logs\Enable-BitLockerEncryption.log',

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$TaskName = 'CHP - Backup BitLocker Recovery Password to Entra ID',

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$TaskPath = '\CHP\'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Write-LogEntry {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Value,

        [Parameter(Mandatory = $false)]
        [ValidateSet('1', '2', '3')]
        [string]$Severity = '1'
    )

    try {
        $LogDirectory = Split-Path -Path $script:LogPath -Parent
        if (-not (Test-Path -Path $LogDirectory)) {
            New-Item -Path $LogDirectory -ItemType Directory -Force | Out-Null
        }

        if (-not (Test-Path -Path 'variable:script:TimezoneBias')) {
            [string]$script:TimezoneBias = [System.TimeZoneInfo]::Local.GetUtcOffset((Get-Date)).TotalMinutes
            if ($script:TimezoneBias -match '^-') {
                $script:TimezoneBias = $script:TimezoneBias.Replace('-', '+')
            }
            else {
                $script:TimezoneBias = '-' + $script:TimezoneBias
            }
        }

        $Time = -join @((Get-Date -Format 'HH:mm:ss.fff'), $script:TimezoneBias)
        $Date = Get-Date -Format 'MM-dd-yyyy'
        $Context = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        $LogText = '<![LOG[{0}]LOG]!><time="{1}" date="{2}" component="BitLockerESP" context="{3}" type="{4}" thread="{5}" file="">' -f $Value, $Time, $Date, $Context, $Severity, $PID

        Out-File -InputObject $LogText -Append -Encoding Default -FilePath $script:LogPath -ErrorAction Stop
    }
    catch {
        Write-Warning "Unable to write to log file '$script:LogPath'. $($_.Exception.Message)"
    }
}

function Exit-WithLog {
    param(
        [Parameter(Mandatory = $true)]
        [int]$ExitCode,

        [Parameter(Mandatory = $true)]
        [string]$Message,

        [Parameter(Mandatory = $false)]
        [ValidateSet('1', '2', '3')]
        [string]$Severity = '1'
    )

    Write-LogEntry -Value $Message -Severity $Severity
    exit $ExitCode
}

function Ensure-64BitPowerShell {
    if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {
        $SysNativePowerShell = Join-Path -Path $env:WINDIR -ChildPath 'SysNative\WindowsPowerShell\v1.0\powershell.exe'
        if (-not (Test-Path -Path $SysNativePowerShell)) {
            Exit-WithLog -ExitCode 1 -Severity '3' -Message '64-bit PowerShell relaunch failed because SysNative powershell.exe was not found.'
        }

        $ArgumentList = @(
            '-ExecutionPolicy', 'Bypass',
            '-NoProfile',
            '-File', ('"{0}"' -f $PSCommandPath),
            '-EncryptionMethod', $EncryptionMethod,
            '-OperationalMode', $OperationalMode,
            '-CompanyName', ('"{0}"' -f $CompanyName),
            '-LogPath', ('"{0}"' -f $LogPath),
            '-TaskName', ('"{0}"' -f $TaskName),
            '-TaskPath', ('"{0}"' -f $TaskPath)
        ) -join ' '

        Write-LogEntry -Value 'Script is running in 32-bit PowerShell. Relaunching in 64-bit PowerShell and waiting for exit code.' -Severity '2'
        $Process = Start-Process -FilePath $SysNativePowerShell -ArgumentList $ArgumentList -Wait -PassThru -WindowStyle Hidden
        exit $Process.ExitCode
    }
}

function Test-AdministratorOrSystem {
    $Identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $Principal = New-Object Security.Principal.WindowsPrincipal($Identity)
    $IsAdmin = $Principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    if (-not $IsAdmin) {
        Exit-WithLog -ExitCode 1 -Severity '3' -Message "Script must run elevated. Current context: $($Identity.Name)"
    }
}

function Get-OSMountPoint {
    $Drive = $env:SystemDrive
    if ([string]::IsNullOrWhiteSpace($Drive)) {
        $Drive = 'C:'
    }
    return $Drive
}

function Get-CurrentBitLockerVolume {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MountPoint
    )

    return Get-BitLockerVolume -MountPoint $MountPoint -ErrorAction Stop
}

function Get-ProtectorState {
    param(
        [Parameter(Mandatory = $true)]
        $Volume
    )

    $Types = @()
    if ($null -ne $Volume.KeyProtector) {
        $Types = @($Volume.KeyProtector | ForEach-Object { $_.KeyProtectorType })
    }

    [PSCustomObject]@{
        HasTpmProtector              = $Types -contains 'Tpm'
        HasRecoveryPasswordProtector = $Types -contains 'RecoveryPassword'
        ProtectorTypes               = ($Types -join ', ')
        RecoveryPasswordProtectors   = @($Volume.KeyProtector | Where-Object { $_.KeyProtectorType -eq 'RecoveryPassword' })
    }
}

function Test-BitLockerESPReady {
    param(
        [Parameter(Mandatory = $true)]
        $Volume
    )

    $ProtectorState = Get-ProtectorState -Volume $Volume
    $AcceptableVolumeStatus = @('FullyEncrypted', 'EncryptionInProgress', 'UsedSpaceOnly')
    $AcceptableProtectionStatus = @('On', 'Unknown')

    return (
        ($AcceptableVolumeStatus -contains [string]$Volume.VolumeStatus) -and
        $ProtectorState.HasTpmProtector -and
        $ProtectorState.HasRecoveryPasswordProtector
    )
}

function Initialize-TPMForBitLocker {
    try {
        $Tpm = Get-Tpm -ErrorAction Stop
        Write-LogEntry -Value "TPM present: $($Tpm.TpmPresent); ready: $($Tpm.TpmReady); enabled: $($Tpm.TpmEnabled); activated: $($Tpm.TpmActivated); owned: $($Tpm.TpmOwned)" -Severity '1'

        if (-not $Tpm.TpmPresent) {
            Exit-WithLog -ExitCode 1 -Severity '3' -Message 'No TPM was detected. BitLocker TPM-only silent encryption cannot continue.'
        }

        if (-not $Tpm.TpmReady) {
            Write-LogEntry -Value 'TPM is present but not ready. Attempting Initialize-Tpm.' -Severity '2'
            try {
                Initialize-Tpm -AllowClear -ErrorAction Stop | Out-Null
                Start-Sleep -Seconds 5
            }
            catch {
                Write-LogEntry -Value "Initialize-Tpm failed or was not applicable: $($_.Exception.Message)" -Severity '2'
            }
        }
    }
    catch {
        Exit-WithLog -ExitCode 1 -Severity '3' -Message "Unable to query TPM state. $($_.Exception.Message)"
    }
}

function Add-MissingKeyProtectors {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MountPoint
    )

    $Volume = Get-CurrentBitLockerVolume -MountPoint $MountPoint
    $ProtectorState = Get-ProtectorState -Volume $Volume

    if (-not $ProtectorState.HasTpmProtector) {
        Write-LogEntry -Value 'TPM key protector is missing. Adding TPM protector.' -Severity '1'
        try {
            Add-BitLockerKeyProtector -MountPoint $MountPoint -TpmProtector -ErrorAction Stop | Out-Null
        }
        catch {
            # Add-BitLockerKeyProtector can fail when BitLocker has not been enabled yet. Enable-BitLocker handles that path.
            Write-LogEntry -Value "Add TPM protector attempt returned: $($_.Exception.Message)" -Severity '2'
        }
    }

    $Volume = Get-CurrentBitLockerVolume -MountPoint $MountPoint
    $ProtectorState = Get-ProtectorState -Volume $Volume

    if (-not $ProtectorState.HasRecoveryPasswordProtector) {
        Write-LogEntry -Value 'Recovery password protector is missing. Adding recovery password protector.' -Severity '1'
        Add-BitLockerKeyProtector -MountPoint $MountPoint -RecoveryPasswordProtector -ErrorAction Stop | Out-Null
    }
}

function Enable-OSDriveBitLocker {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MountPoint
    )

    $Volume = Get-CurrentBitLockerVolume -MountPoint $MountPoint
    Write-LogEntry -Value "Current BitLocker state. MountPoint: $($Volume.MountPoint); VolumeStatus: $($Volume.VolumeStatus); ProtectionStatus: $($Volume.ProtectionStatus); EncryptionPercentage: $($Volume.EncryptionPercentage); EncryptionMethod: $($Volume.EncryptionMethod)" -Severity '1'

    $ProtectorState = Get-ProtectorState -Volume $Volume
    Write-LogEntry -Value "Current key protectors: $($ProtectorState.ProtectorTypes)" -Severity '1'

    if ($Volume.VolumeStatus -eq 'FullyDecrypted' -or $Volume.ProtectionStatus -eq 'Off') {
        Write-LogEntry -Value "Starting BitLocker on $MountPoint using $EncryptionMethod, UsedSpaceOnly, TPM protector, SkipHardwareTest." -Severity '1'
        Enable-BitLocker -MountPoint $MountPoint -EncryptionMethod $EncryptionMethod -UsedSpaceOnly -TpmProtector -SkipHardwareTest -ErrorAction Stop
        Start-Sleep -Seconds 5
    }

    Add-MissingKeyProtectors -MountPoint $MountPoint

    $Volume = Get-CurrentBitLockerVolume -MountPoint $MountPoint

    if ($Volume.ProtectionStatus -eq 'Off' -and $Volume.VolumeStatus -ne 'FullyDecrypted') {
        Write-LogEntry -Value 'BitLocker volume exists but protection is off. Attempting Resume-BitLocker.' -Severity '2'
        try {
            Resume-BitLocker -MountPoint $MountPoint -ErrorAction Stop | Out-Null
        }
        catch {
            Write-LogEntry -Value "Resume-BitLocker failed or was not applicable: $($_.Exception.Message)" -Severity '2'
        }
    }

    $Volume = Get-CurrentBitLockerVolume -MountPoint $MountPoint
    if ($Volume.VolumeStatus -eq 'FullyDecrypted' -and $Volume.ProtectionStatus -eq 'Off') {
        # Fallback path for edge cases where protectors were added but encryption was not started.
        Write-LogEntry -Value 'Fallback: BitLocker still reports FullyDecrypted/Off. Attempting manage-bde -on.' -Severity '2'
        $ManageBde = Start-Process -FilePath 'manage-bde.exe' -ArgumentList "-on $MountPoint -usedspaceonly -skiphardwaretest" -Wait -PassThru -WindowStyle Hidden
        Write-LogEntry -Value "manage-bde exit code: $($ManageBde.ExitCode)" -Severity '1'
    }
}

function Backup-RecoveryKeyToAAD {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MountPoint
    )

    $Volume = Get-CurrentBitLockerVolume -MountPoint $MountPoint
    $ProtectorState = Get-ProtectorState -Volume $Volume

    if (-not $ProtectorState.HasRecoveryPasswordProtector) {
        Write-LogEntry -Value 'Recovery password protector is missing. Cannot escrow recovery key yet.' -Severity '2'
        return $false
    }

    $Success = $false
    foreach ($RecoveryProtector in $ProtectorState.RecoveryPasswordProtectors) {
        try {
            Write-LogEntry -Value "Attempting to escrow recovery password protector $($RecoveryProtector.KeyProtectorId) to Entra ID / Azure AD." -Severity '1'
            BackupToAAD-BitLockerKeyProtector -MountPoint $MountPoint -KeyProtectorId $RecoveryProtector.KeyProtectorId -ErrorAction Stop
            Write-LogEntry -Value "Successfully escrowed recovery password protector $($RecoveryProtector.KeyProtectorId)." -Severity '1'
            $Success = $true
        }
        catch {
            Write-LogEntry -Value "Escrow attempt failed for protector $($RecoveryProtector.KeyProtectorId): $($_.Exception.Message)" -Severity '2'
        }
    }

    return $Success
}

function Set-RegistryValueSafe {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [string]$Value
    )

    if (-not (Test-Path -Path $Path)) {
        New-Item -Path $Path -Force | Out-Null
    }

    New-ItemProperty -Path $Path -Name $Name -PropertyType String -Value $Value -Force | Out-Null
}

function Register-EscrowRetryTask {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RegistryRootPath
    )

    try {
        $StagingRoot = Join-Path -Path $env:ProgramData -ChildPath 'CHP\Scripts'
        if (-not (Test-Path -Path $StagingRoot)) {
            New-Item -Path $StagingRoot -ItemType Directory -Force | Out-Null
        }

        $StagedScript = Join-Path -Path $StagingRoot -ChildPath (Split-Path -Path $PSCommandPath -Leaf)
        Copy-Item -Path $PSCommandPath -Destination $StagedScript -Force

        $TaskArguments = '-ExecutionPolicy Bypass -NoProfile -File "{0}" -OperationalMode Backup -EncryptionMethod {1} -CompanyName "{2}" -LogPath "{3}" -TaskName "{4}" -TaskPath "{5}"' -f $StagedScript, $EncryptionMethod, $CompanyName, $LogPath, $TaskName, $TaskPath

        $Action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $TaskArguments
        $TriggerAtStartup = New-ScheduledTaskTrigger -AtStartup
        $TriggerAtLogon = New-ScheduledTaskTrigger -AtLogOn
        $Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RunOnlyIfNetworkAvailable -MultipleInstances IgnoreNew -StartWhenAvailable -Compatibility Win8
        $Principal = New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        $Task = New-ScheduledTask -Action $Action -Trigger @($TriggerAtStartup, $TriggerAtLogon) -Settings $Settings -Principal $Principal

        Register-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -InputObject $Task -Force | Out-Null
        Set-RegistryValueSafe -Path $RegistryRootPath -Name 'BitLockerEscrowResult' -Value 'Pending'
        Write-LogEntry -Value "Registered escrow retry scheduled task: $TaskPath$TaskName" -Severity '1'
    }
    catch {
        Write-LogEntry -Value "Failed to register escrow retry scheduled task. $($_.Exception.Message)" -Severity '2'
    }
}

function Disable-EscrowRetryTask {
    try {
        $ExistingTask = Get-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -ErrorAction SilentlyContinue
        if ($null -ne $ExistingTask) {
            Disable-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -ErrorAction Stop | Out-Null
            Write-LogEntry -Value "Disabled escrow retry scheduled task: $TaskPath$TaskName" -Severity '1'
        }
    }
    catch {
        Write-LogEntry -Value "Failed to disable escrow retry scheduled task. $($_.Exception.Message)" -Severity '2'
    }
}

try {
    $script:LogPath = $LogPath
    Ensure-64BitPowerShell
    Test-AdministratorOrSystem

    Write-LogEntry -Value "Starting BitLocker ESP script. OperationalMode: $OperationalMode; EncryptionMethod: $EncryptionMethod; ScriptPath: $PSCommandPath" -Severity '1'

    Import-Module -Name BitLocker -DisableNameChecking -ErrorAction Stop

    $RegistryRootPath = "HKLM:\SOFTWARE\$CompanyName"
    if (-not (Test-Path -Path $RegistryRootPath)) {
        New-Item -Path $RegistryRootPath -Force | Out-Null
    }

    $MountPoint = Get-OSMountPoint

    switch ($OperationalMode) {
        'Encrypt' {
            Initialize-TPMForBitLocker
            Enable-OSDriveBitLocker -MountPoint $MountPoint

            $Volume = Get-CurrentBitLockerVolume -MountPoint $MountPoint
            $ProtectorState = Get-ProtectorState -Volume $Volume
            Write-LogEntry -Value "Post-enable state. VolumeStatus: $($Volume.VolumeStatus); ProtectionStatus: $($Volume.ProtectionStatus); EncryptionPercentage: $($Volume.EncryptionPercentage); Protectors: $($ProtectorState.ProtectorTypes)" -Severity '1'

            if (-not (Test-BitLockerESPReady -Volume $Volume)) {
                Exit-WithLog -ExitCode 1 -Severity '3' -Message "BitLocker did not reach ESP-ready state. VolumeStatus: $($Volume.VolumeStatus); ProtectionStatus: $($Volume.ProtectionStatus); Protectors: $($ProtectorState.ProtectorTypes)"
            }

            $EscrowSuccess = Backup-RecoveryKeyToAAD -MountPoint $MountPoint
            if ($EscrowSuccess) {
                Set-RegistryValueSafe -Path $RegistryRootPath -Name 'BitLockerEscrowResult' -Value 'True'
                Disable-EscrowRetryTask
            }
            else {
                Write-LogEntry -Value 'Recovery key escrow did not complete during ESP. Registering retry task and allowing ESP to continue because BitLocker is enabled/in progress with required protectors.' -Severity '2'
                Register-EscrowRetryTask -RegistryRootPath $RegistryRootPath
            }

            Exit-WithLog -ExitCode 0 -Severity '1' -Message "ESP-safe BitLocker validation passed. VolumeStatus: $($Volume.VolumeStatus); EncryptionPercentage: $($Volume.EncryptionPercentage); Protectors: $($ProtectorState.ProtectorTypes)"
        }

        'Backup' {
            $Volume = Get-CurrentBitLockerVolume -MountPoint $MountPoint
            $ProtectorState = Get-ProtectorState -Volume $Volume
            Write-LogEntry -Value "Backup mode state. VolumeStatus: $($Volume.VolumeStatus); ProtectionStatus: $($Volume.ProtectionStatus); EncryptionPercentage: $($Volume.EncryptionPercentage); Protectors: $($ProtectorState.ProtectorTypes)" -Severity '1'

            if (-not $ProtectorState.HasRecoveryPasswordProtector) {
                Set-RegistryValueSafe -Path $RegistryRootPath -Name 'BitLockerEscrowResult' -Value 'False'
                Exit-WithLog -ExitCode 1 -Severity '3' -Message 'Backup mode failed because no recovery password protector exists.'
            }

            $EscrowSuccess = Backup-RecoveryKeyToAAD -MountPoint $MountPoint
            if ($EscrowSuccess) {
                Set-RegistryValueSafe -Path $RegistryRootPath -Name 'BitLockerEscrowResult' -Value 'True'
                Disable-EscrowRetryTask
                Exit-WithLog -ExitCode 0 -Severity '1' -Message 'Backup mode successfully escrowed recovery key to Entra ID / Azure AD.'
            }
            else {
                Set-RegistryValueSafe -Path $RegistryRootPath -Name 'BitLockerEscrowResult' -Value 'False'
                Exit-WithLog -ExitCode 1 -Severity '2' -Message 'Backup mode could not escrow recovery key. The scheduled task can retry at next startup/logon.'
            }
        }
    }
}
catch {
    Write-LogEntry -Value "Unhandled failure. $($_.Exception.Message) Line: $($_.InvocationInfo.ScriptLineNumber)" -Severity '3'
    exit 1
}
