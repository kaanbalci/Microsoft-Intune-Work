<#
.SYNOPSIS
    Intune Win32 detection script for ESP-safe BitLocker state.

.DESCRIPTION
    Returns success when the OS drive is FullyEncrypted, EncryptionInProgress, or UsedSpaceOnly
    and has both TPM and RecoveryPassword key protectors.
#>

try {
    Import-Module BitLocker -DisableNameChecking -ErrorAction Stop

    $MountPoint = if ($env:SystemDrive) { $env:SystemDrive } else { 'C:' }
    $Volume = Get-BitLockerVolume -MountPoint $MountPoint -ErrorAction Stop
    $ProtectorTypes = @($Volume.KeyProtector | ForEach-Object { $_.KeyProtectorType })

    $HasTpmProtector = $ProtectorTypes -contains 'Tpm'
    $HasRecoveryPasswordProtector = $ProtectorTypes -contains 'RecoveryPassword'
    $AcceptableVolumeStatus = @('FullyEncrypted', 'EncryptionInProgress', 'UsedSpaceOnly')

    if (($AcceptableVolumeStatus -contains [string]$Volume.VolumeStatus) -and $HasTpmProtector -and $HasRecoveryPasswordProtector) {
        Write-Output "BitLocker ESP-ready. Status=$($Volume.VolumeStatus); EncryptionPercentage=$($Volume.EncryptionPercentage); Protectors=$($ProtectorTypes -join ', ')"
        exit 0
    }
    else {
        Write-Output "BitLocker not ESP-ready. Status=$($Volume.VolumeStatus); EncryptionPercentage=$($Volume.EncryptionPercentage); Protectors=$($ProtectorTypes -join ', ')"
        exit 1
    }
}
catch {
    Write-Output "BitLocker detection failed. $($_.Exception.Message)"
    exit 1
}
